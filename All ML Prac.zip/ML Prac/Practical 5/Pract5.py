import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest

df = pd.read_csv('p5your_timeseries.csv', parse_dates=['timestamp'], index_col='timestamp')
series = df['value']

model = IsolationForest(contamination=0.01, random_state=42)
df['anomaly'] = model.fit_predict(series.values.reshape(-1,1))
anomalies = df[df['anomaly'] == -1]
print("Anomalies found:", anomalies)
