import pandas as pd
import numpy as np

# Example: 100 samples, 6 sensor features (like accelerometer and gyroscope axes)
np.random.seed(42)
X = pd.DataFrame({
    'accel_x': np.random.randn(100),
    'accel_y': np.random.randn(100),
    'accel_z': np.random.randn(100),
    'gyro_x': np.random.randn(100),
    'gyro_y': np.random.randn(100),
    'gyro_z': np.random.randn(100),
})

# Example activity labels (e.g., walking, running, sitting)
activities = ['Walking', 'Running', 'Sitting']
y = pd.DataFrame({
    'Activity': np.random.choice(activities, size=100)
})

# Save to CSV
X.to_csv('X.csv', index=False)
y.to_csv('y.csv', index=False)

print("✅ Files 'X.csv' and 'y.csv' created successfully.")
