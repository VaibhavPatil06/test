import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

# Load and preprocess data
df = pd.read_csv('loan_data.csv')
df['Loan_Status'] = df['Loan_Status'].map({'Y': 1, 'N': 0})
df.drop(['Loan_ID'], axis=1, inplace=True)
df = pd.get_dummies(df, drop_first=True)

X = df.drop('Loan_Status', axis=1)
y = df['Loan_Status']

# Stratified split with larger test size
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)

# Print class distributions
print("Train class distribution:\n", y_train.value_counts())
print("Test class distribution:\n", y_test.value_counts())

# Train model
clf = RandomForestClassifier(random_state=42)
clf.fit(X_train, y_train)

# Predict on test set
y_pred = clf.predict(X_test)

# Print actual vs predicted labels
print("Actual labels:", y_test.values)
print("Predicted labels:", y_pred)

# Print accuracy and classification report (with zero_division=0 to avoid warnings)
print("Accuracy:", accuracy_score(y_test, y_pred))
print(classification_report(y_test, y_pred, zero_division=0))
