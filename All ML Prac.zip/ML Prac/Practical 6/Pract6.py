import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report

# --- Example dataset creation ---
# 100 samples, 6 sensor features
np.random.seed(42)
X = pd.DataFrame({
    'accel_x': np.random.randn(100),
    'accel_y': np.random.randn(100),
    'accel_z': np.random.randn(100),
    'gyro_x': np.random.randn(100),
    'gyro_y': np.random.randn(100),
    'gyro_z': np.random.randn(100),
})

# Example activity labels
activities = ['Walking', 'Running', 'Sitting']
y = pd.DataFrame({
    'Activity': np.random.choice(activities, size=100)
})

# Save to CSV (optional)
X.to_csv('X.csv', index=False)
y.to_csv('y.csv', index=False)
print("✅ Files 'X.csv' and 'y.csv' created successfully.")

# --- Load CSVs (simulating real dataset) ---
X = pd.read_csv('X.csv')
y = pd.read_csv('y.csv')['Activity']

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Train Random Forest classifier
clf = RandomForestClassifier(random_state=42)
clf.fit(X_train, y_train)

# Predict and evaluate
y_pred = clf.predict(X_test)
print("\nClassification Report:\n")
print(classification_report(y_test, y_pred))
