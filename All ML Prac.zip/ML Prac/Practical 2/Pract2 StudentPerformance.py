import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

# Load data
df = pd.read_csv('StudentsPerformance.csv')

# Drop 'StudentID' if it exists
df = df.drop(columns=['StudentID'], errors='ignore')

# Create 'Pass_Fail' based on average score
passing_marks = 60
df['Pass_Fail'] = (df[['math score', 'reading score', 'writing score']].mean(axis=1) >= passing_marks).astype(int)

# Encode categorical columns
df = pd.get_dummies(df, drop_first=True)

# Features and target
X = df.drop('Pass_Fail', axis=1)
y = df['Pass_Fail']

# Scale features
scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

# Train model
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Evaluation
y_pred = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))
print(classification_report(y_test, y_pred))

