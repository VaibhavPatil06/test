import CodeEditor from "./CodeEditor";
import "./App.css";
function App() {
  return (
    <div className="App">
      <CodeEditor />
    </div>
  );
}
export default App;
