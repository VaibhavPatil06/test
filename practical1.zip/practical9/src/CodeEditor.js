import { useState } from "react";
export default function CodeEditor() {
  const [html, setHtml] = useState("<h1>Hello World</h1>");
  const [css, setCss] = useState("h1 { color: blue; }");
  const [darkMode, setDarkMode] = useState(false);
  const srcCode = `
 <html>
 <head>
 <style>${css}</style>
 </head>
 <body>
 ${html}
 </body>
 </html>`;
  return (
    <div className={darkMode ? "container dark" : "container"}>
      {/* Left: Editor Section */}
      <div className="editor-section">
        <button className="toggle-btn" onClick={() => setDarkMode(!darkMode)}>
          {darkMode ? "☀ Light Mode" : " Dark Mode"}
        </button>
        <h2>HTML</h2>
        <textarea value={html} onChange={(e) => setHtml(e.target.value)} />
        <h2>CSS</h2>
        <textarea value={css} onChange={(e) => setCss(e.target.value)} />
      </div>
      {/* Right: Preview Section */}
      <div className="preview-section">
        <h2>Preview</h2>
        <iframe srcDoc={srcCode} sandbox="allow-scripts" title="preview" />
      </div>
    </div>
  );
}
