import React, { useState, useRef, useEffect } from "react";
import "./App.css";
function App() {
  const [count, setCount] = useState(0);
  const intervalRef = useRef(null);
  const startCounter = () => {
    if (intervalRef.current !== null) return;
    intervalRef.current = setInterval(() => {
      setCount((prev) => prev + 1);
    }, 1000);
  };
  const stopCounter = () => {
    clearInterval(intervalRef.current);
    intervalRef.current = null;
  };
  const resetCounter = () => {
    stopCounter();
    setCount(0);
  };
  useEffect(() => {
    return () => clearInterval(intervalRef.current);
  }, []);
  return (
    <div className="App">
      <h1>React Counter App</h1>
      <h2>Count: {count}</h2>
      <div className="buttons">
        <button onClick={startCounter}>Start</button>
        <button onClick={stopCounter}>Stop</button>
        <button onClick={resetCounter}>Reset</button>
      </div>
    </div>
  );
}
export default App;
