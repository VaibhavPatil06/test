import { useState } from "react";
import "./App.css";
export default function App() {
  const [user1Input, setUser1Input] = useState("");
  const [user2Input, setUser2Input] = useState("");
  const [user1Messages, setUser1Messages] = useState([]);
  const [user2Messages, setUser2Messages] = useState([]);
  // Send from User1 to User2
  const handleSendUser1 = () => {
    if (user1Input.trim() !== "") {
      setUser1Messages([...user1Messages, user1Input]);
      setUser1Input("");
    }
  };
  // Send from User2 to User1
  const handleSendUser2 = () => {
    if (user2Input.trim() !== "") {
      setUser2Messages([...user2Messages, user2Input]);
      setUser2Input("");
    }
  };
  return (
    <div className="container">
      {/* User 1 Section */}
      <div className="user-section">
        <h2> User 1</h2>
        <textarea
          value={user1Input}
          onChange={(e) => setUser1Input(e.target.value)}
          placeholder="Type your message..."
        />
        <button onClick={handleSendUser1}>Send</button>
        <div className="message-box">
          <h3> From User 2:</h3>
          {user2Messages.map((msg, index) => (
            <pre key={index}>{msg}</pre>
          ))}
        </div>
      </div>
      {/* User 2 Section */}
      <div className="user-section">
        <h2> User 2</h2>
        <textarea
          value={user2Input}
          onChange={(e) => setUser2Input(e.target.value)}
          placeholder="Type your message..."
        />
        <button onClick={handleSendUser2}>Send</button>
        <div className="message-box">
          <h3> From User 1:</h3>
          {user1Messages.map((msg, index) => (
            <pre key={index}>{msg}</pre>
          ))}
        </div>
      </div>
    </div>
  );
}
