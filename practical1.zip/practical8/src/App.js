import React, { useState } from "react";
import SearchBar from "./SearchBar";
import RecipeCard from "./RecipeCard";
import "./App.css";
function App() {
  const [recipes, setRecipes] = useState([]);
  const fetchRecipes = (query) => {
    fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${query}`)
      .then((response) => response.json())
      .then((data) => {
        if (data.meals) {
          setRecipes(data.meals);
        } else {
          setRecipes([]);
        }
      })
      .catch(() => {
        setRecipes([]);
      });
  };
  return (
    <div className="app">
      <h1 className="title"> Recipe Search</h1>
      <SearchBar onSearch={fetchRecipes} />
      <div className="recipes-grid">
        {recipes.length === 0 ? (
          <p className="message">Search for a recipe to get started!</p>
        ) : (
          recipes.map((recipe) => (
            <RecipeCard key={recipe.idMeal} recipe={recipe} />
          ))
        )}
      </div>
    </div>
  );
}

export default App;
