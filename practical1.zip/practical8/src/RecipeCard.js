import React from "react";
function RecipeCard({ recipe }) {
  return (
    <div className="recipe-card">
      <img
        src={recipe.strMealThumb}
        alt={recipe.strMeal}
        className="recipe-image"
      />
      <h2 className="recipe-title">{recipe.strMeal}</h2>
      <p className="recipe-category">{recipe.strCategory}</p>
      <a
        href={recipe.strYoutube}
        target="_blank"
        rel="noreferrer"
        className="recipe-link"
      >
        View Recipe
      </a>
    </div>
  );
}
export default RecipeCard;
