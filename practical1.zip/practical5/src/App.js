import React, { useState } from "react";
import axios from "axios";
import "./App.css";
function App() {
  const [city, setCity] = useState("");
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState("");
  const getWeather = async () => {
    if (!city) return;
    try {
      setError("");
      const res = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=075080168ae25df4b86aa37a334e7b7c&units=metric`
      );
      setWeather(res.data);
    } catch {
      setError("City doesnt exists");
      setWeather(null);
    }
  };
  return (
    <div className="weather-container">
      <h1 className="weather-title">Weather App</h1>

      <div className="input-group">
        <input
          type="text"
          placeholder="Enter city"
          className="weather-input"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          onKeyPress={(e) => e.key === "Enter" && getWeather()}
        />

        <button onClick={getWeather} className="weather-btn">
          Search
        </button>
      </div>

      {error && <p className="error-text">{error}</p>}

      {weather && (
        <div className="weather-card">
          <h2>{weather.name}</h2>
          <p className="description">{weather.weather[0].description}</p>
          <p className="temp-text">{weather.main.temp}°C</p>

          <div className="weather-stats">
            <p>Humidity: {weather.main.humidity}%</p>
            <p>Wind: {weather.wind.speed} m/s</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
