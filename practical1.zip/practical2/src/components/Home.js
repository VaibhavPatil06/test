import React from "react";
import { Link } from "react-router-dom";
import "./Home.css";
const pokemons = ["pikachu", "bulbasaur", "charmander", "squirtle"];
export default function Home() {
  return (
    <div className="home">
      <h2>Select a Pokémon</h2>
      {pokemons.map((name) => (
        <div key={name}>
          <Link to={`/pokemon/${name}`}>
            <button className="pokebutton">{name.toUpperCase()}</button>
          </Link>
        </div>
      ))}
    </div>
  );
}
