import React, { useRef, useState } from "react";

const MusicPlayer = () => {
  const audioRef = useRef(null);

  const playlist = [
    {
      name: "Song One",
      url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
    },
    {
      name: "Song Two",
      url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
    },
    {
      name: "Song Three",
      url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [playing, setPlaying] = useState(false);

  const playPause = () => {
    const audio = audioRef.current;
    if (playing) {
      audio.pause();
      setPlaying(false);
    } else {
      audio.play();
      setPlaying(true);
    }
  };

  const playNext = () => {
    let next = (currentIndex + 1) % playlist.length;
    setCurrentIndex(next);
    setPlaying(false);
    setTimeout(() => audioRef.current.play(), 100);
    setPlaying(true);
  };

  const playPrev = () => {
    let prev = (currentIndex - 1 + playlist.length) % playlist.length;
    setCurrentIndex(prev);
    setPlaying(false);
    setTimeout(() => audioRef.current.play(), 100);
    setPlaying(true);
  };

  return (
    <div style={{ textAlign: "center" }}>
      {/* Song Title */}
      <h2 style={{ fontSize: "24px", fontWeight: "bold" }}>
        {playlist[currentIndex].name}
      </h2>

      <audio ref={audioRef} src={playlist[currentIndex].url} />

      {/* Buttons */}
      <div style={{ marginTop: "10px" }}>
        <button style={btnStyle} onClick={playPrev}>
          ⏮
        </button>
        <button style={btnStyle} onClick={playPause}>
          {playing ? "⏸ Pause" : "▶ Play"}
        </button>
        <button style={btnStyle} onClick={playNext}>
          ⏭
        </button>
      </div>
    </div>
  );
};

const btnStyle = {
  padding: "6px 15px",
  margin: "0 5px",
  border: "1px solid #333",
  borderRadius: "5px",
  background: "#fff",
  cursor: "pointer",
};

export default MusicPlayer;
