const products = [
  {
    id: 1,
    name: "Apple iPhone 15",
    price: 70000,
    image: "https://m.media-amazon.com/images/I/71d7rfSl0wL.jpg",
  },
  {
    id: 2,
    name: "Samsung Galaxy S23",
    price: 55000,
    image:
      "https://m.media-amazon.com/images/I/717Q2swzhBL._AC_UF1000,1000_QL80_.jpg",
  },
  {
    id: 3,
    name: "Sony Wireless Headphones",
    price: 3000,
    image: "https://m.media-amazon.com/images/I/41lArSiD5hL.jpg",
  },
  {
    id: 4,
    name: "Dell Inspiron Laptop",
    price: 85000,
    image: "https://m.media-amazon.com/images/I/71h9nOTd93L._SL1500_.jpg",
  },
];

export default products;
