import React from "react";

const Cart = ({ cart, updateQuantity, removeFromCart }) => {
  return (
    <div className="cart">
      <h2>Your Cart</h2>

      {cart.length === 0 ? <p>No items in cart</p> : null}

      {cart.map((item) => (
        <div key={item.id}>
          <h4>{item.name}</h4>
          <p>Price: ₹{item.price}</p>

          <div>
            <button onClick={() => updateQuantity(item.id, "decrease")}>
              -
            </button>
            <span style={{ margin: "0 10px" }}>{item.quantity}</span>
            <button onClick={() => updateQuantity(item.id, "increase")}>
              +
            </button>
          </div>

          <button
            style={{ backgroundColor: "red", marginTop: "5px" }}
            onClick={() => removeFromCart(item.id)}
          >
            Remove
          </button>

          <hr />
        </div>
      ))}
    </div>
  );
};

export default Cart;
