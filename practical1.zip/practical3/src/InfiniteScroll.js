import React, { useEffect, useState } from "react";
const InfiniteScroll = () => {
  const [items, setItems] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true); // stop when all data is loaded
  const fetchData = async () => {
    if (loading) return;
    setLoading(true);
    try {
      const res = await fetch(
        `https://jsonplaceholder.typicode.com/posts?_page=${page}&_limit=10`
      );
      const data = await res.json();
      if (data.length === 0) {
        setHasMore(false); // No more posts
      } else {
        setItems((prev) => [...prev, ...data]);
        setPage((prev) => prev + 1);
      }
    } catch (err) {
      console.error("Error fetching data:", err);
    }
    setLoading(false);
  };
  useEffect(() => {
    fetchData();
  }, []);
  useEffect(() => {
    const handleScroll = () => {
      if (
        window.innerHeight + document.documentElement.scrollTop + 50 >=
        document.documentElement.offsetHeight
      ) {
        if (!loading && hasMore) {
          fetchData();
        }
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [loading, hasMore]);
  return (
    <div style={{ padding: "20px" }}>
      <h2>Infinite Scroll with API</h2>
      <ul>
        {items.map((item) => (
          <li key={item.id} style={{ marginBottom: "15px", fontSize: "16px" }}>
            <strong>
              {item.id}. {item.title}
            </strong>
            <p>{item.body}</p>
          </li>
        ))}
      </ul>
      {loading && <p>Loading more items...</p>}
      {!hasMore && <p>No more data to load.</p>}
    </div>
  );
};
export default InfiniteScroll;
