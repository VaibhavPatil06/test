import React from "react";
import InfiniteScroll from "./InfiniteScroll";
function App() {
  return (
    <div>
      <InfiniteScroll />
    </div>
  );
}
export default App;
